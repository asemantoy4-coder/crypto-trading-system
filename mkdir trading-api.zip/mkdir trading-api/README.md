# Crypto AI Trading System API

A professional trading signals API built with FastAPI and Python.

## Features
- Real-time scalp signals
- Ichimoku cloud analysis
- Smart entry calculation
- Risk management
- REST API with full documentation

## API Endpoints

### Health Check